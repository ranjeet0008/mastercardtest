/**
 * 
 */
package com.address.demo.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.address.demo.entity.Address;
import com.address.demo.service.AddressService;

/**
 * @author sharatmeitei
 *
 */

@RunWith(SpringRunner.class)
@DataJpaTest
class AddressRepositoryTest {
	@Autowired
	AddressRepository addressRepository;

	@Test
	public void testFindAll() {
		List<Address> addressList = addressRepository.findAll();
		assertEquals(4, addressList.size());

	}

	@Test
	public void testFindByCountryCodelUSA() {
		List<Address> addressList = addressRepository.findByCountryCode("USA");
		assertEquals(3, addressList.size());

	}

	@Test
	public void testFindByCountryCodelCN() {
		List<Address> addressList = addressRepository.findByCountryCode("CN");
		assertEquals(1, addressList.size());

	}

}
