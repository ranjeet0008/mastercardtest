INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (100,'317','Prairie Point',NULL,'OFallon','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (200,'470','Chesterfield',NULL,'Chesterfield','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (300,'500','Canada',NULL,'Canada','CA','CN');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (700,'317','Prairie Point',NULL,'OFallon','MO','USA');
